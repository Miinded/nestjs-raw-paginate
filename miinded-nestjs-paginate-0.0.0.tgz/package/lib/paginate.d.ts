import { PaginateConfig as OPaginateConfig, Paginated, PaginateQuery } from 'nestjs-paginate';
import { ColumnProperties } from 'nestjs-paginate/lib/helper';
import { FilterComparator, FilterOperator, FilterSuffix } from 'nestjs-paginate/lib/filter';
import { FindOperator, ObjectLiteral, SelectQueryBuilder } from 'typeorm';
import { ColumnMetadata } from 'typeorm/metadata/ColumnMetadata';
export type RawPaginateConfig<T> = Omit<OPaginateConfig<T>, 'where' | 'relations' | 'loadEagerRelations'> & {
    metadataColumns?: {
        [key: string]: string;
    };
};
export declare function rawPaginate<T extends ObjectLiteral>(query: PaginateQuery, qb: SelectQueryBuilder<T>, config: RawPaginateConfig<T>): Promise<Paginated<T>>;
export declare function getCount(qb: SelectQueryBuilder<ObjectLiteral>): Promise<number>;
type Filter = {
    comparator: FilterComparator;
    findOperator: FindOperator<string>;
};
type ColumnsFilters = {
    [columnName: string]: Filter[];
};
export declare function parseFilterForRawQuery<T>(query: PaginateQuery, filterableColumns?: {
    [column: string]: (FilterOperator | FilterSuffix)[] | true;
}, qb?: SelectQueryBuilder<T>, metadataColumns?: {
    [column: string]: string;
}): ColumnsFilters;
export declare function formatFilter<T>(qb: SelectQueryBuilder<T>, query: PaginateQuery, filterableColumns?: {
    [column: string]: (FilterOperator | FilterSuffix)[] | true;
}, metadataColumns?: {
    [column: string]: string;
}): ColumnsFilters;
export declare function addFilter<T>(qb: SelectQueryBuilder<T>, query: PaginateQuery, filterableColumns?: {
    [column: string]: (FilterOperator | FilterSuffix)[] | true;
}, metadataColumns?: {
    [column: string]: string;
}): SelectQueryBuilder<T>;
export declare function fixRawColumnFilterValue<T>(column: string, qb: SelectQueryBuilder<T>, metadataColumns?: {
    [column: string]: string;
}, isJsonb?: boolean): (value: string) => string | number | Date;
export declare function addWhereCondition<T>(qb: SelectQueryBuilder<T>, column: string, filter: ColumnsFilters): void;
export declare function extractVirtualProperty(qb: SelectQueryBuilder<unknown>, columnProperties: ColumnProperties): Partial<ColumnMetadata>;
export declare function checkIsArray(qb: SelectQueryBuilder<unknown>, propertyName: string): boolean;
export declare function checkIsJsonb(qb: SelectQueryBuilder<unknown>, propertyName: string): boolean;
export {};
